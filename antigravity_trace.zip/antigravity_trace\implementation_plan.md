# Smart Fallback for Agentic Pipeline (Bypassing Gemini Limits)

This plan outlines the steps to implement a fully functional JavaScript fallback. If the Gemini API hits its rate limit (429) or runs out of credits, the app will continue to function using real-time Google Maps data without crashing or resorting to hardcoded mock providers.

## Proposed Changes

### `src/services/geminiService.js`
We will introduce a new `smartFallbackLoop` function and update the error handling in `runAgenticLoop` to use it.

#### [MODIFY] `src/services/geminiService.js`
1. **Create `smartFallbackLoop(systemInstruction, userPrompt, onUpdate)`**:
   - **Stage 1 (Intent)**: Use basic JavaScript Regular Expressions to scan the `userPrompt` for keywords (like "plumber", "ac repair") and locations (words following "in", "near", or "mein").
   - **Stage 2 (Discovery)**: Call `geocodeLocation(extractedLocation)` and `searchNearbyProviders(lat, lng, extractedService)` to fetch *real* Google Maps data.
   - **Stage 3 (Ranking & Pricing)**: If real providers are found, write a standard JS loop to calculate `composite_score` (e.g., using `rating * 20 - distance_km * 2`). Sort the providers and generate a dynamic pricing estimate based on the top provider's distance.
   - **Ultimate Fallback**: If even Google Maps fails (or returns 0 results), fallback to the original `simulateAgenticLoop` mock data as a final safety net.
2. **Update `runAgenticLoop`**:
   - In the `catch` block (line ~195), change `return simulateAgenticLoop(...)` to `return smartFallbackLoop(...)`.

## User Review Required

> [!IMPORTANT]
> The smart fallback will execute instantly and skip the "AI Reasoning" steps. The ranking reasons will be generated using a basic template (e.g., "Ranked based on high rating and close distance") rather than AI-generated sentences. Please review and approve this approach before I implement the code!
